#!/usr/bin/env python3

import requests
import json
import sys

# Configuration Proxmox
PROXMOX_API_URL = "https://server1.chichopital.bj:8006/api2/json"
PROXMOX_USER = "ansible-admin@pve!QXORmZwSzYvYBRQXVldOaAdM"
PROXMOX_TOKEN = "c903d1ab-7732-410e-9634-82ef66d249e8"

# Fonction pour récupérer les machines virtuelles depuis Proxmox
def get_proxmox_vms():
    headers = {"Authorization": f"PVEAPIToken={PROXMOX_TOKEN}"}
    response = requests.get(f"{PROXMOX_API_URL}/nodes", headers=headers)

    if response.status_code != 200:
        print("Erreur API Proxmox:", response.text)
        sys.exit(1)

    nodes = response.json().get("data", [])
    inventory = {"_meta": {"hostvars": {}}}
    groups = {"proxmox_vms": {"hosts": []}}

    for node in nodes:
        node_name = node["node"]
        vms_response = requests.get(f"{PROXMOX_API_URL}/nodes/{node_name}/qemu", headers=headers)

        if vms_response.status_code == 200:
            vms = vms_response.json().get("data", [])
            for vm in vms:
                vm_name = vm["name"]
                vm_id = vm["vmid"]
                vm_status = vm["status"]
                vm_ip = vm.get("ip", "Non défini")

                inventory["_meta"]["hostvars"][vm_name] = {
                    "ansible_host": vm_ip,
                    "vmid": vm_id,
                    "node": node_name,
                    "status": vm_status
                }

                groups["proxmox_vms"]["hosts"].append(vm_name)

    inventory.update(groups)
    print(json.dumps(inventory, indent=4))

# Exécuter le script
if __name__ == "__main__":
    get_proxmox_vms()